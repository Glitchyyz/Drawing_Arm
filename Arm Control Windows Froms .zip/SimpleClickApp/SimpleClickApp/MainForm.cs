﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading; // Required for file writing
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Text.RegularExpressions;
using System.Reflection;

namespace SimpleClickApp
{
    // This is the main form of our application
    public partial class MainForm : Form
    {
        // A list to store the locations where the user clicked
        private List<Point> clickLocations = new List<Point>();
        double Z = 140;
        double X = 100;
        double Y = 0;
        bool Ready = true;
        string LastCommand = "150,0,0";
        string[] ports = null;
        bool InterpolationEnabled = false;
        int ClawOpenness = 80;
        Image ORIGINALIMAGE = null;
        // Constructor for the form
        public MainForm()
        {

            InitializeComponent();
            CheckAvailablePorts();
            // Enable double buffering to reduce flickering when repainting
            this.DoubleBuffered = true;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;


        }
        private void CheckAvailablePorts()
        {
            ports = SerialPort.GetPortNames();
            comboBox1.Items.Clear();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void SENDCOMMAND()
        {
            

            if (X > 400) // make sure it dosent go over certain values
            {
                X = 400;
            }
            else if (X-200 < -200)
            {
                X = 0;
            }

            if (Y > 300)
            {
                Y = 300;
            }else if (Y < 0)
            {
                Y = 0;
            }


            if (label1.InvokeRequired) // fixes weired bug that crashes app
            {
                label1.Invoke((MethodInvoker)delegate
                {
                    label1.Text = "Z: " + Z;
                });
            }
            else
            {
              
                label1.Text = "Z: " + Z;
            }


            if (label2.InvokeRequired)
            {
                label2.Invoke((MethodInvoker)delegate
                {
                    label2.Text = "X: " + (X - 200 );
                });
            }
            else
            {
                
                label2.Text = "X: " + (X - 200);
            }

            if (label3.InvokeRequired)
            {
                label3.Invoke((MethodInvoker)delegate
                {
                    label3.Text = "Y: " + ((Y));
                });
            }
            else
            {
                
                label3.Text = "Y: " + ((Y));
            }
            double sendX = X - 200;
            string COMMAND = $"{(sendX)},{(Y)},{Z},{ClawOpenness}\n";

            if(serialPort1.IsOpen && Ready == true)
            {
                UseWaitCursor = true;
                if (InterpolationEnabled != checkBox1.Checked)
                {
                    InterpolationEnabled = checkBox1.Checked;
                    if (InterpolationEnabled == false)
                    {
                        serialPort1.Write("FT\n");
                        Ready = false;
                    }
                    else
                    {
                        serialPort1.Write("IN\n");
                        Ready = false;
                    }
                }
            }
            
            if (Ready && serialPort1.IsOpen) // Sends the data to arduino via SerialPort
            {





                
                UseWaitCursor = true;
                serialPort1.Write(COMMAND);
                LastCommand = COMMAND;
                Ready = false;
            }
            else if(!Ready && serialPort1.IsOpen)
            {
                LastCommand = COMMAND;
            }
            
        }


      

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            Z = vScrollBar1.Value;
            SENDCOMMAND();
        }

     

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
                UseWaitCursor=false;
               Cursor.Current = Cursors.Default;
                Ready = true;
            Application.DoEvents();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            clickLocations.Clear();
            this.Invalidate();
            panel1.Invalidate(); 
        }



        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Ready = true;
            serialPort1.Close();
            serialPort1.PortName = ports[comboBox1.SelectedIndex];
            
            serialPort1.BaudRate = 9600;
            try
            {
                serialPort1.Open(); // Attempt to open the serial port
                Console.WriteLine($"Serial port {serialPort1.PortName} opened successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening serial port: {ex.Message}", "Serial Port Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {

                if (Ready)
                {
                    Point clickPoint = new Point(e.X, e.Y);
                    clickLocations.Add(clickPoint);
                }
                X = 400 -e.X;
                Y = e.Y;
                
                
                SENDCOMMAND();
                this.Invalidate();
                panel1.Invalidate();
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            
            X =400 - e.X;
            Y = e.Y;
            if (Ready)
            {
                Point clickPoint = new Point(e.X, e.Y);
                clickLocations.Add(clickPoint);
            }

            SENDCOMMAND();
            this.Invalidate();
            
        }

        private void comboBox1_Enter(object sender, EventArgs e)
        {
            serialPort1.Close();
            ports = SerialPort.GetPortNames();
            comboBox1.Items.Clear();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            using (SolidBrush blackBrush = new SolidBrush(Color.Red))
            {
                int squareSize = 4;

                
                foreach (Point location in clickLocations)
                {

                    int x = location.X  - squareSize / 2;
                    int y = location.Y  - squareSize / 2;


                    e.Graphics.FillEllipse(blackBrush, x, y, squareSize, squareSize);

                }
            }
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            ClawOpenness = hScrollBar1.Value;
            
            SENDCOMMAND();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Y = Y - 10;
            SENDCOMMAND();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            X = X - 10;
            SENDCOMMAND();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Y = Y + 10;
            SENDCOMMAND();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            X = X + 10;
            SENDCOMMAND();
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            SENDCOMMAND();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select Image";
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filepath = openFileDialog.FileName;
                Image image = Image.FromFile(filepath);
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox1.Image = image;
                ORIGINALIMAGE = image;

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (ORIGINALIMAGE != null)
            {
                Image originalImage = ORIGINALIMAGE;

                // Use the actual image size, not PictureBox size
                float scaleFactor = Math.Min(100f / originalImage.Width, 100f / originalImage.Height);

                int newWidth = (int)(originalImage.Width * scaleFactor);
                int newHeight = (int)(originalImage.Height * scaleFactor);

                // Create a new bitmap and draw the resized image into it
                Bitmap resizedImage = new Bitmap(newWidth, newHeight);
                using (Graphics g = Graphics.FromImage(resizedImage))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(originalImage, 0, 0, newWidth, newHeight);
                }

                // Process the image to black & white based on brightness
                for (int y = 0; y < resizedImage.Height; y++)
                {
                    for (int x = 0; x < resizedImage.Width; x++)
                    {
                        Color pixelColour = resizedImage.GetPixel(x, y);
                        bool isBlack = pixelColour.GetBrightness() < (double)vScrollBar2.Value / 100;

                        resizedImage.SetPixel(x, y, isBlack ? Color.Black : Color.White);
                    }
                }

                pictureBox1.Image = resizedImage;
            }


        }
        private void UpdateProgressBar(int value)
        {
            progressBar1.Value = value;
        }
        private void UpdatePanel()
        {
            panel1.Invalidate();
        }
        private void ChangeInterpolation(bool ISInterpoalted)
        {
            checkBox1.Checked = ISInterpoalted;
        }
        private void Print()
        {
             
            if (pictureBox1.Image != null)

            {
                Bitmap ImageMap = new Bitmap(pictureBox1.Image);
                checkBox1.Invoke(new Action<bool>(ChangeInterpolation), true);

                for (int i = 0; i < ImageMap.Height; i = i + 2)
                {
                    
                    progressBar1.Invoke(new Action<int>(UpdateProgressBar),(int)Math.Round(((double)i /ImageMap.Height)*100));
                     

                    for (int I = 0; I < ImageMap.Width; I = I + 2)
                    {
                        Color pixelColour = ImageMap.GetPixel(I, i);
                        bool Isblack = pixelColour.GetBrightness() < (double)vScrollBar2.Value / 100;

                        if (Isblack)
                        {
                            
                            Point clickPoint = new Point( I+200 - ImageMap.Width / 2, i + 120);
                            clickLocations.Add(clickPoint);
                            panel1.Invoke(new Action(UpdatePanel));
                            
                            
                            Y = 100 + i ;
                            X = 200 - I + (double)ImageMap.Width/2 ;
                            Z = -40;


                            SENDCOMMAND();

                            while (!Ready)
                            {
                                try
                                {
                                    
                                }
                                catch
                                {
                                }
                            }
                            checkBox1.Invoke(new Action<bool>(ChangeInterpolation), true);
                            SENDCOMMAND();
                            while (!Ready)
                            {
                                try
                                {

                                }
                                catch
                                {
                                }

                            }

                            
                            
                            Z = -55;
                            SENDCOMMAND();
                            while (!Ready)
                            {
                                try
                                {
                                    
                                }
                                catch
                                {
                                }

                            }
                            Thread.Sleep(250);
                           
                            Z = -40;
                            SENDCOMMAND();
                            while (!Ready)
                            {
                                try
                                {
                                    
                                }
                                catch
                                {
                                }

                            }
                            checkBox1.Invoke(new Action<bool>(ChangeInterpolation), false);
                            SENDCOMMAND();
                            while (!Ready)
                            {
                                try
                                {

                                }
                                catch
                                {
                                }

                            }

                        }

                    }
                }

                pictureBox1.Image = new Bitmap(ImageMap);
            }
            
        }
        private async void button8_Click(object sender, EventArgs e)
        {
            
            button8.Enabled = false;
            
            


            try
            {
                // Run the long-running function on a separate thread
                await Task.Run(() => Print());

                // Update the UI after the function completes (back on the UI thread)
                
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occurred in the background thread
                MessageBox.Show($"An error occurred: {ex.Message}");
                
            }
            finally
            {
                // Re-enable the button
                button8.Enabled = true;
                progressBar1.Value = 0;
            }
        }
        private void PrintLine(double x2, double y2, double x1, double y1, double e, double LastE)
        {
            double distance = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            Console.WriteLine(distance/e);
            
               
           
           
           
            

            double stepCount = Math.Ceiling(distance / 1); // Split into smaller moves
            for (int i = 0; i < stepCount; i++)
            {
                double prog = (i + 1) / stepCount;
                X = x1 - (x1 - x2) * prog;
                X = X + 250;
                Y = y1 - (y1 - y2) * prog;
                Y = Y + 30;
                //Point clickPoint = new Point((int)X , (int)Y);
               // clickLocations.Add(clickPoint);
               // panel1.Invoke(new Action(UpdatePanel));
                
                SENDCOMMAND();
                while (!Ready)
                {
                    try
                    {

                    }
                    catch
                    {
                    }

                }
                Thread.Sleep(1);
                 // Small delay between steps
            }
            


            SENDCOMMAND();
            while (!Ready)
            {
                try
                {

                }
                catch
                {
                }

            }
            
        }
        private void ParseGcode(string Gcode)
        {
            Bitmap LAYER = new Bitmap(200, 200);
            double LastX = 0;
            double LastY = 0;
            double LastE = 0;

            string[] lines = Gcode.Split('\n');
            foreach (string line in lines)
            {
                if (line.StartsWith("G1"))
                {   
                    
                    Match matchY = Regex.Match(line, @"Y(\d*\.?\d*)");
                    Match matchX = Regex.Match(line, @"X(\d*\.?\d*)");
                    Match matchE = Regex.Match(line, @"E(\d*\.?\d*)");
                    double.TryParse(matchY.Groups[1].Value, out double yval);
                    double.TryParse(matchX.Groups[1].Value, out double xval);
                    double.TryParse(matchE.Groups[1].Value, out double eval);
                    if (xval != 0 && yval != 0)
                    {
                        LAYER.SetPixel((int)xval, (int)yval, Color.Black);
                        
                        PrintLine(xval, yval, LastX, LastY, eval, LastE);
                        Z = -50;
                        using (Graphics g = Graphics.FromImage(LAYER))
                        {
                            Pen pen = new Pen(Color.Black, 1); // Line color and thickness

                            // Define two points
                            Point startPoint = new Point((int)xval, (int)yval);
                            Point endPoint = new Point((int)LastX, (int)LastY);

                            // Draw the line
                            g.DrawLine(pen, startPoint, endPoint);
                        }

                        LastE = eval;
                        LastX = xval;
                        LastY = yval;

                    }


                }
                else if (line.StartsWith("G0"))
                {

                    Match matchZ = Regex.Match(line, @"Z(\d)");
                    Match matchY = Regex.Match(line, @"Y(\d*\.?\d*)");
                    Match matchX = Regex.Match(line, @"X(\d*\.?\d*)");
                    double.TryParse(matchY.Groups[1].Value, out double yval);
                    double.TryParse(matchX.Groups[1].Value, out double xval);
                    double.TryParse(matchZ.Groups[1].Value, out double zval);

                    LAYER.SetPixel((int)xval, (int)yval, Color.Black);
                    

                    if (zval != 2 && zval != 0)
                    {
                        pictureBox1.Image = LAYER;
                        break;

                    }
                    Z = -30;
                    PrintLine(xval, yval, LastX, LastY, 0, LastE);
                    Z = -30;
                    LastX = xval;
                    LastY = yval;

                }
            }
        }

        private async void button9_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "GCode Files (*.gcode)|*.gcode|All Files (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string gcodeContent = File.ReadAllText(openFileDialog.FileName);
                button9.Enabled = false;
                try
                {
                    // Run the long-running function on a separate thread
                    await Task.Run(() => ParseGcode(gcodeContent));

                    // Update the UI after the function completes (back on the UI thread)

                }
                catch (Exception ex)
                {
                   
                    MessageBox.Show($"An error occurred: {ex.Message}");

                }
                finally
                {
                   
                    button9.Enabled = true;
                    progressBar1.Value = 0;
                }
                
            }
        }
    }
    public class DoubleBufferedPanel : Panel
    {
        public DoubleBufferedPanel()
        {
            // Enable double buffering 
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.UserPaint |
                          ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.OptimizedDoubleBuffer, true);
        }
    }

}
